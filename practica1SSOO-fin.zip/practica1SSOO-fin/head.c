#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void printLine(int n)
{
                        //Recibimos el valor de un entero en la variable [n]
    char text[1000];    //Contiene el valor de la línea a leer, max. 1000 chrts.
    int i = 0;          //Contador para realizar [n] iteraciones
    while(fgets(text, 1000, stdin) != NULL && i < n){  //Con cada iteración, se actualiza el contenido de [text]
        printf("%s", text);
        i++;            //actualizamos el valor del contador [i]
    }
    exit(0);
}